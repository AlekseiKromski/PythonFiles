from random import*
kolods=[6,7,8,9,10,11,12,13,14]*4
def mang_21():
    shuffle (kolods)
    print('Alustame mängida ')
    summa=0
    while 1:
        valik=input('Kas kaardi võtad7 y(yes) n(no)')
        if valik=='y':
            karta=kolods.pop()
            print('Sinu kaart on ',karta)
            summa+=karta
            if summa>21:
                print('Sina kaotasid! Sul on',summa)
                break
            elif summa==21:
                print('Sinu võtsid :(')
                break
            else:
                print('Sul on ',summa)
        elif valik=='n':
            print('Sul on ',summa,'Ja sinu isa lpemisest mängu')
            break
mang_21()       

