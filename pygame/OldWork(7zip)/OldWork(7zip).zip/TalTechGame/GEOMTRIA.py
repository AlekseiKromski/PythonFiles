from turtle import*
from random import*
colormode(255)
shape('turtle')
mitu=int(numinput("?",'Mitu turtle7 '))
a=numinput('a','1. kulje pukus')
def kolmunik(x,y,a,joon):
    pensize(joon)
    pencolor(randint(1,255),randint(1,225),randint(1,225))
    seth(0)
    goto(x,y)
    pendown()
    for i in range(3):
        fd(a)
        left(120)
    penup()

for i in range(mitu):
    pu()
    kolmunik(0-a*i,0-a/2*i,a+i*2*a,5)
