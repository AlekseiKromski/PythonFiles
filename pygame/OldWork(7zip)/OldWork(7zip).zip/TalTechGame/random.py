from random import*

print('Atva arv 1 kuni 100 ')
x=randint(1,100)
print(x)
k=y=0
while y!=x:
    y=input('Paku midagi,lipetamiseks vajuta tühik ')
    if y==' ':
        print('Kahju!')
        break
    y=int(y)
    k=k+1 #k+=1
    if y > x:
        print('liiga palju')
    elif y < x:
        print('liiga vähe')
    else:
        print('MUidugi, hea töö,',k,'sinu arv: ',x)
    if k > 8:
        print('sinu mäng lõpp')
        break

        





