from random import*
print('Kull või kiri')
while 1:
    try:
        bank=int(input('Kui palju raha sul on '))
        break
    except ValueError:
        print('See ei ole arv')
if bank <=0:
    print('Ei ole rahu ei ole mängu!')
else:
    print('Hakkame mängida! ')
    while bank > 0:
        x=randint(1,2)
        while 1:
            try:
                panus=int(input('Kui palju panustab7 '))
                break
            except ValueError:
                print('See ei ole arv')
        if x > bank:
            print('Ei ole nii palju')
            print('Sul on ainult ',bank)
            break
        else:
            print(x)
            print('Sinu panus on acpt')
            y =input('Kull (1) või kiri (2), lõppetamiseks tühik')
            if y==' ':
                print('kahju saaksime veel mänguda')
                print('sul on',bank)
                break
            y=int(y)
            if  y==x:
                print('Sinu võit')
                bank+=panus
                print('sul on',bank)
            elif y<=0 or y>2:
                print('see ei ole reeglid')
                print('Sul on',bank)
                break
            else:
                print('Minu võit')
                bank-=panus
                print('Sul on',bank)
print('Mäng lõpp')
