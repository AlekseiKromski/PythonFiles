#Kromski
'''
class address():
       name='z'
       line1='z'
       line2='z'
       city='z'
       state='z'
       zip='z'
def printAddress(address):
       print(address.name)
       if(len(address.line1) > 0):
              print(address.line1)
       if(len(address.line2) > 0):
              print(address.line2)
       print(address.city+", "+address.state+" "+address.zip)
printAddress(address())
'''
#1
class Dog():
       age = 0
       name = ""
       weight = 0
dogg = Dog()
dogg.age = 24
dogg.name = "Holly"
dogg.weight = 22
#2 - 3
class sanja():
       age = 0
       cellPhone = ""
       email = ""
class dima():
       age = 0
       cellPhone = ""
       email = ""
#Sanja
Sanja = sanja()
Sanja.age = 98
Sanja.cellPhone = "WindowsPhone"
Sanja.email = 'sanja@mail.ru'
#Dima
Dima = dima()
Dima.age = 58
Dima.cellPhone = "Iphone"
Dima.email = 'dima@mail.ru'
#4
class Gerolt():
       age = 'unknown'
       x = 103
       y = 200
       name = 'Gerolt'
       power = 500
#5
class Person():
       name = ""
       money = 0
nancy = Person()
nancy.name = "Nancy"
nancy.money = 100
#6
class Person():
       name = ""
       money = 0
bob = Person()
bob.name = "Bob"
print(bob.name , "has" , bob.money , "dollars.")
       




